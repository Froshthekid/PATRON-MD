const chalk = require("chalk")
const fs = require("fs")
//auto presence update
global.autoTyping = false //auto tying in gc (true to on, false to off)
global.autoRecord = true //auto recording (true to on, false to off)
global.autoblockmorroco = true //auto block 212 (true to on, false to off)
global.autokickmorroco = true //auto kick 212 (true to on, false to off) 
global.antispam = true //auto kick spammer (true to on, false to off)
//===============SETTING MENU==================\\
function _0x6e24(){var _0x5c78f5=['13209250uMnVNa','3oTJXuL','GitHub:\x20Itzpatron','andana','ownername','1492MRNTav','11209143JsVlSJ','48tsodMR','ᴘᴀᴛʀᴏɴ-ᴍᴅ','botname','Nigeria','socialm','ownernomer','angopay','438LQLrsL','ownernumber','2348133729715','nodana','PATRON\x20🚹','168zUqXCN','justt.patron','nogopay','15295wOcmNS','owner','FADARE','location','2179244aHbiKK','843yVMciv','42235tLHQMg','./data/image/thumb.jpg','8133729715','10889415ZFociw'];_0x6e24=function(){return _0x5c78f5;};return _0x6e24();}var _0x58159b=_0x168f;function _0x168f(_0x2db1ad,_0x500e0b){var _0x6e2460=_0x6e24();return _0x168f=function(_0x168fff,_0x10b160){_0x168fff=_0x168fff-0x121;var _0xd54aaa=_0x6e2460[_0x168fff];return _0xd54aaa;},_0x168f(_0x2db1ad,_0x500e0b);}(function(_0x385124,_0x533608){var _0x2cc83a=_0x168f,_0x3ece05=_0x385124();while(!![]){try{var _0xa524b2=parseInt(_0x2cc83a(0x138))/0x1*(-parseInt(_0x2cc83a(0x122))/0x2)+-parseInt(_0x2cc83a(0x13e))/0x3*(-parseInt(_0x2cc83a(0x137))/0x4)+parseInt(_0x2cc83a(0x139))/0x5*(-parseInt(_0x2cc83a(0x12b))/0x6)+-parseInt(_0x2cc83a(0x133))/0x7*(parseInt(_0x2cc83a(0x130))/0x8)+-parseInt(_0x2cc83a(0x13c))/0x9+-parseInt(_0x2cc83a(0x13d))/0xa+parseInt(_0x2cc83a(0x123))/0xb*(parseInt(_0x2cc83a(0x124))/0xc);if(_0xa524b2===_0x533608)break;else _0x3ece05['push'](_0x3ece05['shift']());}catch(_0x20afa6){_0x3ece05['push'](_0x3ece05['shift']());}}}(_0x6e24,0xc2f91),global['thumbnail']=fs['readFileSync'](_0x58159b(0x13a)),global['ig']=_0x58159b(0x131),global['yt']='Itzpatron1',global['ttowner']=_0x58159b(0x131),global[_0x58159b(0x121)]=_0x58159b(0x12f),global[_0x58159b(0x134)]=[_0x58159b(0x12d)],global[_0x58159b(0x129)]=_0x58159b(0x12d),global[_0x58159b(0x128)]=_0x58159b(0x13f),global[_0x58159b(0x136)]=_0x58159b(0x127),global[_0x58159b(0x12e)]='8133729715',global[_0x58159b(0x132)]='8133729715',global['noovo']=_0x58159b(0x13b),global[_0x58159b(0x140)]=_0x58159b(0x135),global[_0x58159b(0x12a)]=_0x58159b(0x135),global['anovo']=_0x58159b(0x135),global[_0x58159b(0x126)]=_0x58159b(0x125),global[_0x58159b(0x12c)]=_0x58159b(0x12d));
var _0x4746bf=_0x148d;function _0x148d(_0x2b6c77,_0x83b2f6){var _0x2337fb=_0x2337();return _0x148d=function(_0x148d13,_0x4e7b65){_0x148d13=_0x148d13-0x11e;var _0x1c948e=_0x2337fb[_0x148d13];return _0x1c948e;},_0x148d(_0x2b6c77,_0x83b2f6);}function _0x2337(){var _0x41f0c5=['561896TpdndG','author','2348133729715@s.whatsapp.net','1iHSTbK','84iaPbEu','wagc','1081076EhLbVk','227616AmSLUk','ownerNumber','botscript','10Avvgco','4nLFWrG','ᴘᴀᴛʀᴏɴ-ᴍᴅ🚹','https://github.com/Itzpatron/PATRON-MD','3039765UxuMjB','455754TopaZc','ᴘᴀᴛʀᴏɴ-ᴍᴅ','Sticker\x20created\x20by','ᴘᴀᴛʀᴏɴ-ᴍᴅ\x20🚹','20802199deYjhP','ownername','https://whatsapp.com/channel/0029Val0s0rIt5rsIDPCoD2q','5033331EAqKxB','ownerweb'];_0x2337=function(){return _0x41f0c5;};return _0x2337();}(function(_0x4519e8,_0x31b9b9){var _0x5f3a31=_0x148d,_0x34aea7=_0x4519e8();while(!![]){try{var _0xb572bf=parseInt(_0x5f3a31(0x126))/0x1*(parseInt(_0x5f3a31(0x129))/0x2)+parseInt(_0x5f3a31(0x12a))/0x3*(parseInt(_0x5f3a31(0x12e))/0x4)+-parseInt(_0x5f3a31(0x131))/0x5+parseInt(_0x5f3a31(0x132))/0x6*(-parseInt(_0x5f3a31(0x127))/0x7)+parseInt(_0x5f3a31(0x123))/0x8+-parseInt(_0x5f3a31(0x121))/0x9+parseInt(_0x5f3a31(0x12d))/0xa*(parseInt(_0x5f3a31(0x11e))/0xb);if(_0xb572bf===_0x31b9b9)break;else _0x34aea7['push'](_0x34aea7['shift']());}catch(_0x399d66){_0x34aea7['push'](_0x34aea7['shift']());}}}(_0x2337,0x79d5c),global[_0x4746bf(0x11f)]=_0x4746bf(0x12f),global[_0x4746bf(0x12b)]=['2348133729715@s.whatsapp.net'],global[_0x4746bf(0x122)]=_0x4746bf(0x120),global['websitex']=_0x4746bf(0x120),global[_0x4746bf(0x128)]=_0x4746bf(0x120),global['saluran']=_0x4746bf(0x120),global['themeemoji']='🚹',global['wm']=_0x4746bf(0x133),global[_0x4746bf(0x12c)]=_0x4746bf(0x130),global['packname']=_0x4746bf(0x134),global[_0x4746bf(0x124)]=_0x4746bf(0x135),global['creator']=_0x4746bf(0x125));
global.botnumber = '23413483643344'
global.bankname = "MONIEPOINT"
global.banknumber = "8133729715"
global.bankowner = "FADARE"
//======================== CPANEL COMMAND ===========================\\
global.domain = '-' // Fill in your domain, don't put a / at the end of the link
global.apikey = '-' // Fill Apikey
global.capikey = '-' // Fill Apikey
//=========================================================//
//Server create panel egg pm2
global.apikey2 = '-' // Fill Apikey
global.capikey2 = '-' // Fill Apikey
global.domain2 = '-' // Fill Domain
global.docker2 = "ghcr.io/cekilpedia/vip:sanzubycekil" //don't change it

global.eggsnya2 = '15' // ID of eggs used
global.location2 = '1' // id location
//===========================//
global.domainotp = "https://claudeotp.com/api"
global.apikeyotp = "a395f97fe99f4fad0e790d10af518b9a"
global.eggsnya = '15' // ID of eggs used
global.location3 = '1' // id location
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.tekspushkonv3 = ""
global.tekspushkonv4 = ""
//===========================//

global.decor = {
	menut: '❏═┅═━–〈',
	menub: '┊•',
	menub2: '┊',
	menuf: '┗––––––––––✦',
	hiasan: '꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷',

	menut: '––––––『',
    menuh: '』––––––',
    menub: '┊☃︎ ',
    menuf: '┗━═┅═━––––––๑\n',
	menua: '',
	menus: '☃︎',

	htki: '––––––『',
	htka: '』––––––',
	haki: '┅━━━═┅═❏',
	haka: '❏═┅═━━━┅',
	lopr: 'Ⓟ',
	lolm: 'Ⓛ',
	htjava: '❃'
}

//===========================//

global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            makanancentaur: "🥗",
            makanangriffin: "🥙",
            makanankyubi: "🍗",
            makanannaga: "🍖",
            makananpet: "🥩",
            makananphonix: "🧀",
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            naga: "🐉",
            phonix: "🦅",
            kyubi: "🦊",
            griffin: "🦒",
            centaur: "🎠",
            skata: '🧩'
        }
        let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
        if (!results.length) return ''
        else return emot[results[0][0]]
    }
}

//new
global.prefix = ['!','.','#','&']
global.sessionName = 'session'
global.hituet = 0
//media target
global.thum = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.log0 = fs.readFileSync("./data/image/thumb.jpg") //ur logo pic
global.err4r = fs.readFileSync("./data/image/thumb.jpg") //ur error pic
global.thumb = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.defaultpp = 'https://i.imgur.com/5wsWcjp.jpeg' //default pp wa

//menu image maker
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='

//messages
global.mess = {
wait: "*_ᴘᴀᴛʀᴏɴ🚹, ᴡᴀɪᴛ!!!._*",
   success: "ʜᴇʜᴇ, *ɪᴛ ᴡᴀꜱ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟ🚹*",
   on: "ɪᴛ'ꜱ ᴀᴄᴛɪᴠᴇ🚹", 
   off: "ɪᴛ'ꜱ ᴏꜰꜰ ꜱɪʀ🚹",
   query: {
       text: "ᴡʜᴇʀᴇ ɪꜱ ᴛʜᴇ ᴛᴇxᴛ ʙʀᴏ?🚹",
       link: "ᴡʜᴇʀᴇ'ꜱ ᴛʜᴇ ʟɪɴᴋ?🚹",
   },
   error: {
       fitur: "ʏᴏᴏ ꜱᴏʀʀʏ, ᴇʀʀᴏʀ ꜰᴇᴀᴛᴜʀᴇ, ᴘʟᴇᴀꜱᴇ ᴄʜᴀᴛ ᴡɪᴛʜ ᴛʜᴇ ʙᴏᴛ ᴅᴇᴠᴇʟᴏᴘᴇʀ ꜱᴏ ɪᴛ ᴄᴀɴ ʙᴇ ꜰɪxᴇᴅ ɪᴍᴍᴇᴅɪᴀᴛᴇʟʏ. 🚹",
   },
   only: {
       group: "ʏᴏᴏ ᴍᴀɴ, ʏᴏᴜ ᴄʀᴀᴢʏ? ᴛʜɪꜱ ꜰᴇᴀᴛᴜʀᴇ ᴄᴀɴ ᴏɴʟʏ ʙᴇ ᴜꜱᴇᴅ ɪɴ ɢʀᴏᴜᴘꜱ. 🚹",
       private: "ʙʀᴜʜ ᴡᴛꜰ. ᴛʜɪꜱ ꜰᴇᴀᴛᴜʀᴇ ᴄᴀɴ ᴏɴʟʏ ʙᴇ ᴜꜱᴇᴅ ɪɴ ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ. 🚹",
       owner: "ʏᴏᴏ ʙʀᴏ ɢᴛꜰ. ᴛʜɪꜱ ꜰᴇᴀᴛᴜʀᴇ ᴄᴀɴ ᴏɴʟʏ ʙᴇ ᴜꜱᴇᴅ ʙʏ ʙᴏᴛ ᴏᴡɴᴇʀꜱ. 🚹",
       admin: "ʏᴏᴏ ʙʀᴏ ɢᴛꜰ. ᴛʜɪꜱ ꜰᴇᴀᴛᴜʀᴇ ᴄᴀɴ ᴏɴʟʏ ʙᴇ ᴜꜱᴇᴅ ʙʏ ʙᴏᴛ ᴏᴡɴᴇʀꜱ. 🚹",
       badmin: "ᴍᴀᴋᴇ ᴍᴇ ᴀᴅᴍɪɴ ꜰɪʀꜱᴛ ɴɪɢɢᴀ. 🚹",
       premium: "ɴɪɢɢᴀ ᴡᴛꜰ ʏᴏᴜ ᴀɪɴ'ᴛ ᴍʏ ᴏᴡɴᴇʀ. 🚹",
   }
}
 
//if api key expire, u can generate one from here: https://beta.openai.com/account/api-keys
global.keyopenai = "pk-pIWAlRroXTOAigkWdHcYvmlmgzEQXuoMWbVAaLAVZswSRbEB"
//documents variants
global.doc1 = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.doc2 = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.doc3 = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.doc4 = 'application/zip'
global.doc5 = 'application/pdf'
global.doc6 = 'application/vnd.android.package-archive'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
